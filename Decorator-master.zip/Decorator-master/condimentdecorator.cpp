#include "condimentdecorator.h"

CondimentDecorator::CondimentDecorator()
{

}

CondimentDecorator::~CondimentDecorator()
{

}
