#include "espresso.h"

Espresso::Espresso()
{
    description = "Espresso";
}

Espresso::~Espresso()
{

}

double Espresso::cost() {
    return 1.99;
}
